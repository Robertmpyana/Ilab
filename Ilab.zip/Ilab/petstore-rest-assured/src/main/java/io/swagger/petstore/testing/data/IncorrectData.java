package io.swagger.petstore.testing.data;

public class IncorrectData {
    public static final String INCORRECT_JSON = "{ \"id\": incorrectValue}";
}
