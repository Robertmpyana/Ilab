package io.swagger.petstore.testing.models.pet;

public enum Status {
    available, pending, sold
}
